--Using the SHOW ERRORS function
SHOW ERRORS PROCEDURE error_salary;

--Actually querying the user_errors view
SELECT * FROM user_errors;